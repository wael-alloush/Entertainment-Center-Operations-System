<!DOCTYPE html>
<html lang="ar" dir="rtl">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>

        <?php
            $faviconIco = public_path('favicon.ico');
            $faviconPng = public_path('images/logo-icon.png');
            $faviconIcoVersion = file_exists($faviconIco) ? filemtime($faviconIco) : null;
            $faviconPngVersion = file_exists($faviconPng) ? filemtime($faviconPng) : null;
        ?>
        <?php if($faviconIcoVersion): ?>
            <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>?v=<?php echo e($faviconIcoVersion); ?>" sizes="32x32" type="image/x-icon">
            <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>?v=<?php echo e($faviconIcoVersion); ?>" type="image/x-icon">
        <?php endif; ?>
        <?php if($faviconPngVersion): ?>
            <link rel="icon" href="<?php echo e(asset('images/logo-icon.png')); ?>?v=<?php echo e($faviconPngVersion); ?>" type="image/png" sizes="32x32">
            <link rel="apple-touch-icon" href="<?php echo e(asset('images/logo-icon.png')); ?>?v=<?php echo e($faviconPngVersion); ?>">
        <?php endif; ?>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=noto-sans-arabic:400,500,600,700" rel="stylesheet" />

        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
    </head>
    <body class="font-sans antialiased">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html>
<?php /**PATH C:\projects\buds\resources\views/app.blade.php ENDPATH**/ ?>