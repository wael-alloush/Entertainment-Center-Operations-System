# Inertia

- Inertia creates fully client-side rendered SPAs without modern SPA complexity, leveraging existing server-side patterns.
- Components live in ___SINGLE_BACKTICK___<?php echo e($assist->inertia()->pagesDirectory()); ?>___SINGLE_BACKTICK___ (unless specified in ___SINGLE_BACKTICK___vite.config.js___SINGLE_BACKTICK___). Use ___SINGLE_BACKTICK___Inertia::render()___SINGLE_BACKTICK___ for server-side routing instead of Blade views.
- ALWAYS use ___SINGLE_BACKTICK___search-docs___SINGLE_BACKTICK___ tool for version-specific Inertia documentation and updated code examples.
<?php if($assist->hasPackage(\Laravel\Roster\Enums\Packages::INERTIA_REACT)): ?>
- IMPORTANT: Activate ___SINGLE_BACKTICK___inertia-react-development___SINGLE_BACKTICK___ when working with Inertia client-side patterns.
<?php elseif($assist->hasPackage(\Laravel\Roster\Enums\Packages::INERTIA_VUE)): ?>
- IMPORTANT: Activate ___SINGLE_BACKTICK___inertia-vue-development___SINGLE_BACKTICK___ when working with Inertia Vue client-side patterns.
<?php elseif($assist->hasPackage(\Laravel\Roster\Enums\Packages::INERTIA_SVELTE)): ?>
- IMPORTANT: Activate ___SINGLE_BACKTICK___inertia-svelte-development___SINGLE_BACKTICK___ when working with Inertia Svelte client-side patterns.
<?php endif; ?>

# Inertia v2

- Use all Inertia features from v1 and v2. Check the documentation before making changes to ensure the correct approach.
- New features: deferred props, infinite scroll, merging props, polling, prefetching, once props, flash data.
- When using deferred props, add an empty state with a pulsing or animated skeleton.<?php /**PATH C:\projects\buds\storage\framework\views/93dd1b762f2927fece5039c9b2cac4fe.blade.php ENDPATH**/ ?>