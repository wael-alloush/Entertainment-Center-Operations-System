import * as React from 'react';

import { cn } from '@/lib/utils';

interface SwitchProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'onChange'> {
    checked?: boolean;
    onCheckedChange?: (checked: boolean) => void;
}

const Switch = React.forwardRef<HTMLButtonElement, SwitchProps>(
    ({ className, checked = false, onCheckedChange, disabled, ...props }, ref) => (
        <button
            type="button"
            role="switch"
            aria-checked={checked}
            disabled={disabled}
            ref={ref}
            onClick={() => onCheckedChange?.(!checked)}
            className={cn(
                'peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50',
                checked ? 'bg-primary' : 'bg-input',
                className,
            )}
            {...props}
        >
            <span
                className={cn(
                    'pointer-events-none block size-5 rounded-full bg-background shadow-lg ring-0 transition-transform',
                    checked ? 'translate-x-5 rtl:-translate-x-5' : 'translate-x-0',
                )}
            />
        </button>
    ),
);
Switch.displayName = 'Switch';

export { Switch };
